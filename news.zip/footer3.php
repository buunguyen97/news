
<div class="column column_1_3">
    <h4 class="box_header">Latest Galleries</h4>
    <div class="horizontal_carousel_container big page_margin_top">
        <ul class="blog horizontal_carousel visible-1 autoplay-0 scroll-1 navigation-1 easing-easeInOutQuint duration-750">
            <li class="post">
                <a href="post_gallery.html" title="Struggling Nuremberg Sack Coach Verbeek">
                    <span class="icon gallery"></span>
                    <img src='images/samples/330x242/image_03.jpg' alt='img'>
                </a>
                <h5 class="with_number">
                    <a href="post_gallery.html" title="Struggling Nuremberg Sack Coach Verbeek">Struggling Nuremberg Sack Coach Verbeek</a>
                    <a class="comments_number" href="post_gallery.html#comments_list" title="2 comments">2<span class="arrow_comments"></span></a>
                </h5>
                <ul class="post_details simple">
                    <li class="category"><a href="category_sports.html" title="SPORTS">SPORTS</a></li>
                    <li class="date">
                        10:11 PM, Feb 02
                    </li>
                </ul>
            </li>
            <li class="post">
                <a href="post_gallery.html" title="Built on Brotherhood, Club Lives Up to Name">
                    <span class="icon gallery"></span>
                    <img src='images/samples/330x242/image_14.jpg' alt='img'>
                </a>
                <h5 class="with_number">
                    <a href="post_gallery.html" title="Built on Brotherhood, Club Lives Up to Name">Built on Brotherhood, Club Lives Up to Name</a>
                    <a class="comments_number" href="post_gallery.html#comments_list" title="2 comments">2<span class="arrow_comments"></span></a>
                </h5>
                <ul class="post_details simple">
                    <li class="category"><a href="category_sports.html" title="SPORTS">SPORTS</a></li>
                    <li class="date">
                        10:11 PM, Feb 02
                    </li>
                </ul>
            </li>
            <li class="post">
                <a href="post_gallery.html" title="New Painkiller Rekindles Addiction Concerns">
                    <span class="icon gallery"></span>
                    <img src='images/samples/330x242/image_04.jpg' alt='img'>
                </a>
                <h5 class="with_number">
                    <a href="post_gallery.html" title="New Painkiller Rekindles Addiction Concerns">New Painkiller Rekindles Addiction Concerns</a>
                    <a class="comments_number" href="post_gallery.html#comments_list" title="2 comments">2<span class="arrow_comments"></span></a>
                </h5>
                <ul class="post_details simple">
                    <li class="category"><a href="category_sports.html" title="SPORTS">SPORTS</a></li>
                    <li class="date">
                        10:11 PM, Feb 02
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>