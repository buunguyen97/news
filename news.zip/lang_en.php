<?php
define("BAN_XEM_CHUA","Have you seen?");
define("LOAI_TIN","Categories");
define("TRANG_CHU","Homepage");
define("MOI_NHAN","Newly received");
define("TU_KHOA","Keyword");
define("TIN_TUC_TONG_HOP","GENERAL NEWS");
define("SUB_SITETITLE","Hot news, read fast, read quickly");
define("TIN_MOI_NHAT","Latest news");
define("TIN_NOI_BAT","Hot news");
define("TIN_XEM_NHIEU","See more news");
define("MOI_PHAN_HOI","New feedback");
define("VE_CHUNG_TOI","About us");
define("LHCK","Contact us via channels");
define("TOMTAT","Daily news hourly, all fields, all kinds of upper yellow bran panic bran, quickly synthesized, all over the region.");
define("DIACHI","Address");
define("DAUTRANG","Top");
define("TTT","Next news");
define("YKBD","Comments reader");
define("GYK","Submit comments");
define("NAME","Yours name");
define("EMAIL","Yours Email");
define("MESS","Yours comment");





