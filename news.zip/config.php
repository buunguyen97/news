<?php

    define("DBHOST", "localhost");
    define("DBNAME", "news");
    define("DBUSER", "root");
    define("DBPASS", "");
    define("PAGEGINATION_PERPAGE", 8);
    define("PAGEGINATION_OFFSET", 3);
